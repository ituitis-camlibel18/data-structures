/* @Author
Student Name: Celal �aml�bel
Student ID : 150180092
Date: 11.01.2022 

-std=c++11 needs to be added to the calico file since unordered_map is not supported in c++99 which is default compiler in ssh.

In Case 2, oil and cornflakes have the same revenue in Tuesday so I had to add a sort by name feature to my sorting algorithm. The products are printed in reverse lexicographical order when more than one product has the same value.
*/

#include <iostream>

#include <stdio.h>

#include <stdlib.h>

#include<string>

#include <map>

#include <unordered_map>

#include <fstream>

#include <iomanip>

using namespace std;

string file_path;
class product {//Product class to store data in an organized way
  public:
    string name;
  double price;
  int quantity;
  string day;
  double revenue;
  product * next;
  product(string name1, double price1, int quantity1, string day1) {//constructor

    name = name1;
    price = price1;
    quantity = quantity1;
    day = day1;
    revenue = quantity1 * price1;

  };

};

class day {//day class to store products together in desired way

  public:
    string name;
  product * head;

  day(string name1) {

    name = name1;
    head = NULL;

  };

};
//Main Functions
bool perform_operation(char);
void print_menu();
void listProducts();
void listDay();
//---------------
void add(day * , product * );


//Main Functions
int main(int argc, char * argv[]) {
  bool end = false;
  char choice;
  ifstream inFile;

  file_path = argv[1];

  inFile.open(file_path.c_str());
  if (!inFile.is_open()) {
    cerr << "File cannot be opened";
    return EXIT_FAILURE;
  }

  while (!end) {
    print_menu();
    cin >> choice;
    end = perform_operation(choice);
  }

  inFile.close();
  return EXIT_SUCCESS;

}

void print_menu() {
  cout << "Choose an operation" << endl;
  cout << "L: List 5 products with the highest revenue for total" << endl;
  cout << "D: List 5 products with the highest revenue for each day" << endl;
  cout << "E: Exit" << endl;
  cout << "Enter a choice {L, D, E}: ";
}

bool perform_operation(char choice) {
  bool terminate = false;
  string strday;

  switch (choice) {
  case 'L':
  case 'l':
    listProducts();
    break;
  case 'D':
  case 'd':
    listDay();
    break;
  case 'E':
  case 'e':
    terminate = true;
    break;
  default:
    cout << "Error: You have entered an invalid choice" << endl;
    cin >> choice;
    terminate = perform_operation(choice);
    break;
  }
  return terminate;
}

//---------------

//The functions I added to the file

//Sorting algorithm that needed to print results in descending order
void sortList(product * head_ref) {
  product * current = head_ref, * index = NULL;
  product * temp = new product("", 0, 0, "");

  if (head_ref == NULL) {
    return;
  } else {
    while (current != NULL) {
      // index points to the node next to current
      index = current -> next;

      while (index != NULL) {
        if (current -> revenue <= index -> revenue) {
          temp -> revenue = current -> revenue;
          temp -> name = current -> name;
          temp -> quantity = current -> quantity;
          temp -> price = current -> price;
          temp -> day = current -> day;

          current -> revenue = index -> revenue;
          current -> name = index -> name;
          current -> quantity = index -> quantity;
          current -> price = index -> price;
          current -> day = index -> day;

          index -> revenue = temp -> revenue;
          index -> name = temp -> name;
          index -> quantity = temp -> quantity;
          index -> price = temp -> price;
          index -> day = temp -> day;
          if (current -> revenue == index -> revenue && current -> name < index -> name) {
            temp -> revenue = current -> revenue;
            temp -> name = current -> name;
            temp -> quantity = current -> quantity;
            temp -> price = current -> price;
            temp -> day = current -> day;

            current -> revenue = index -> revenue;
            current -> name = index -> name;
            current -> quantity = index -> quantity;
            current -> price = index -> price;
            current -> day = index -> day;

            index -> revenue = temp -> revenue;
            index -> name = temp -> name;
            index -> quantity = temp -> quantity;
            index -> price = temp -> price;
            index -> day = temp -> day;

          }
        }
        index = index -> next;
      }
      current = current -> next;
    }
  }
}
//day objects to store products for each day
day * monday = new day("Monday");
day * sunday = new day("Sunday");
day * tuesday = new day("Tuesday");
day * wednesday = new day("Wednesday");
day * thursday = new day("Thursday");
day * friday = new day("Friday");
day * saturday = new day("Saturday");
//------------------------------------------

//Object to store all products in a week
day * total = new day("total");
//-----------------------


//Array to access each day without implementing one by one
day * week[7] = {
  monday,
  sunday,
  tuesday,
  wednesday,
  thursday,
  friday,
  saturday
};
//------------------------------------------


//Pushes product if there is no product in the list with the same name. Adds product values if there is a product in the list.
void add(day * day_to_add, product * product_to_push) {

  if (day_to_add -> head == NULL) {

    day_to_add -> head = product_to_push;

  } else {
    bool exist = false;
    product * temp = day_to_add -> head;
    while (temp != NULL) {
      if (temp -> name == product_to_push -> name) {
        temp -> quantity += product_to_push -> quantity;
        temp -> revenue = temp -> quantity * temp -> price;
        exist = true;
        break;//I added a break statement since there will not be other product with the same name in the rest of the linked list.
      }

      temp = temp -> next;
    }
    if (exist == false) {
      product_to_push -> next = day_to_add -> head;
      day_to_add -> head = product_to_push;

    }

  }

}
//--------------


//The boolean value to avoid reading the file again. 
bool file_read = false;
//---------------------------------


//Reads the file and stores product in desired structure. I had to open same file twice because when I tried to assign total and each day values in the same loop it messes the structure up.
void read_file_day() {

  fstream file;
  string name_;
  double price_;
  int quantity_;
  string day_;
  file.open(file_path.c_str());
  file >> name_ >> name_ >> name_ >> name_;

  while (file >> name_ >> price_ >> quantity_ >> day_) {
    product * from_file = new product(name_, price_, quantity_, day_);

    if (day_ == "Monday") {
      add(monday, from_file);

    } else if (day_ == "Sunday") {
      add(sunday, from_file);

    } else if (day_ == "Tuesday") {
      add(tuesday, from_file);

    } else if (day_ == "Wednesday") {
      add(wednesday, from_file);

    } else if (day_ == "Thursday") {
      add(thursday, from_file);

    } else if (day_ == "Friday") {
      add(friday, from_file);

    } else if (day_ == "Saturday") {
      add(saturday, from_file);

    }
  }
  sortList(monday -> head);
  sortList(sunday -> head);
  sortList(tuesday -> head);
  sortList(wednesday -> head);
  sortList(thursday -> head);
  sortList(friday -> head);
  sortList(saturday -> head);

  file.close();
  fstream file1;
  string name_1;
  double price_1;
  int quantity_1;
  string day_1;
  file1.open(file_path.c_str());
  file1 >> name_1 >> name_1 >> name_1 >> name_1;

  while (file1 >> name_1 >> price_1 >> quantity_1 >> day_1) {
    product * from_file1 = new product(name_1, price_1, quantity_1, day_1);
    //cout<< from_file->name << " "<< from_file->price <<" " <<from_file->quantity<<" "<<from_file->day<<endl;
    add(total, from_file1);

  }
  file1.close();

}
//-----------------------------

//Prints the 5 products with the highest revenue
void print_day(day * day_to_print) {

  product * temp1;
  temp1 = day_to_print -> head;
  int count = 0;
  while (count < 5) {
    cout << fixed << temp1 -> name << " " << setprecision(2) << temp1 -> revenue << endl;

    temp1 = temp1 -> next;
    count++;

  }

};
//--------------------------------
//--------------------------------
//The functions I changed
void listProducts() {
  if (!file_read) {
    read_file_day();
    file_read = true;
  }

  sortList(total -> head);
  cout << "5 products with the highest revenue for " + total -> name + " are:" << endl;
  print_day(total);

}

void listDay() {
  if (!file_read) {
    read_file_day();
    file_read = true;
  }
  for (int i = 0; i < 7; i++) {
    cout << "5 products with the highest revenue for " + week[i] -> name + " are:" << endl;
    print_day(week[i]);

  }

}

//-----------------------------
