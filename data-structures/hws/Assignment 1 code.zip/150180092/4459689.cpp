/* @Author 
Student Name: Celal Çamlıbel
Student ID : 150180092
Date: 10.11.2021 */

#include <iostream>

#include <stdio.h>

#include <string.h>

#include "linkedList.h"

using namespace std;

void Train::create() {
  head = NULL;
};
void Train::checkempty(int ishead) {
  wagonNode * temp = head;
  if (ishead == 0) {

    delete head;
    head = NULL;

  } else {

    while (temp -> next -> next != NULL) {
      temp = temp -> next;
    }

    temp -> next = NULL;
  }

};
void Train::swapNode(materialNode * mymaterial) {

  materialNode * temphead = mymaterial;

  char temproll;
  int tempweight;

  int counter = 0;
  while (temphead) {
    temphead = temphead -> next;
    counter++;
  }
  temphead = mymaterial;

  for (int j = 0; j < counter; j++) {
    while (temphead -> next) //iterate through list until next is null
    {
      if (temphead -> id > temphead -> next -> id) {

        temproll = temphead -> id;
        temphead -> id = temphead -> next -> id;
        temphead -> next -> id = temproll;

        tempweight = temphead -> weight;
        temphead -> weight = temphead -> next -> weight;
        temphead -> next -> weight = tempweight;

        temphead = temphead -> next; //increment node
      } else
        temphead = temphead -> next; //increment node
    }
    temphead = mymaterial; //reset temphead
  }

};

void Train::addMaterial(char material, int weight) {

  if (head == NULL) {
    if (weight <= 2000) {

      wagonNode * tempWagon = new wagonNode;
      materialNode * tempMat = new materialNode;
      tempMat -> id = material;
      tempMat -> weight = weight;
      tempMat -> next = NULL;
      tempWagon -> material = tempMat;

      tempWagon -> wagonId = 1;
      tempWagon -> next = NULL;

      head = tempWagon;

    } else {

      wagonNode * tempWagon = new wagonNode;

      materialNode * tempMat = new materialNode;
      tempMat -> id = material;
      tempMat -> weight = 2000;
      tempMat -> next = NULL;
      tempWagon -> material = tempMat;

      tempWagon -> wagonId = 1;
      tempWagon -> next = NULL;
      head = tempWagon;
      addMaterial(material, weight - 2000);

    }

  } else {
    int nonavailable = 0;
    int matavailable = 0;
    int numWagon = 0;
    int indexwagon = 0;
    wagonNode * searchWagon = head;
    while (searchWagon != NULL) {

      materialNode * searchMat = searchWagon -> material;
      while (searchMat != NULL) {

        if (searchMat -> id == material) {
          matavailable = 1;
          indexwagon = numWagon;
          if (searchMat -> weight + weight <= 2000) {
            nonavailable = 1;
            searchMat -> weight = searchMat -> weight + weight;

          } else {

            weight = searchMat -> weight + weight - 2000;
            searchMat -> weight = 2000;

          }

        }
        searchMat = searchMat -> next;

      }
      if (matavailable == 0) {
        if (weight <= 2000) {
          materialNode * newmat = new materialNode;
          newmat -> id = material;
          newmat -> weight = weight;
          newmat -> next = searchWagon -> material;
          searchWagon -> material = newmat;
          swapNode(searchWagon -> material);
          nonavailable = 1;
          break;
        } else {

          materialNode * newmat = new materialNode;
          newmat -> id = material;
          newmat -> weight = 2000;
          newmat -> next = searchWagon -> material;
          searchWagon -> material = newmat;
          swapNode(searchWagon -> material);
          nonavailable = 1;
          addMaterial(material, weight - 2000);

          break;

        }
      }

      searchWagon = searchWagon -> next;
      numWagon++;

    }
    if (nonavailable == 0) {
      if (weight <= 2000) {

        wagonNode * tempWagon = new wagonNode; //new wagon

        materialNode * tempMat = new materialNode;
        tempMat -> id = material;
        tempMat -> weight = weight;
        tempWagon -> material = tempMat;
        tempWagon -> wagonId = numWagon + 1;
        wagonNode * tempWagon1 = new wagonNode; //temp wagon
        tempWagon1 = head;

        int i = 0;
        for (i = 0; i < indexwagon; i++) {
          if (tempWagon1 -> next != NULL) {
            tempWagon1 = tempWagon1 -> next;

          }

        }
        if (tempWagon1 -> next == NULL) {
          tempWagon -> next = tempWagon1 -> next;
          tempWagon1 -> next = tempWagon;
        } else {
          tempWagon1 = tempWagon1 -> next;
          materialNode * newmat = new materialNode;
          newmat -> id = material;
          newmat -> weight = weight;
          newmat -> next = tempWagon1 -> material;
          tempWagon1 -> material = newmat;
          swapNode(tempWagon1 -> material);
          nonavailable = 1;

        }
      } else {

        wagonNode * tempWagon = new wagonNode;
        materialNode * tempMat = new materialNode;
        tempMat -> id = material;
        tempMat -> weight = 2000;

        tempWagon -> material = tempMat;

        tempWagon -> wagonId = numWagon + 1;
        wagonNode * tempWagon1 = new wagonNode; //temp wagon
        tempWagon1 = head;
        int i = 0;
        for (i = 0; i < indexwagon; i++) {
          if (tempWagon1 -> next != NULL) {
            tempWagon1 = tempWagon1 -> next;

          }

        }
        if (tempWagon1 -> next == NULL) {
          tempWagon -> next = tempWagon1 -> next;
          tempWagon1 -> next = tempWagon;
          addMaterial(material, weight - 2000);
        } else {
          tempWagon1 = tempWagon1 -> next;
          materialNode * newmat = new materialNode;
          newmat -> id = material;
          newmat -> weight = 2000;
          newmat -> next = tempWagon1 -> material;
          tempWagon1 -> material = newmat;
          swapNode(tempWagon1 -> material);
          nonavailable = 1;
          addMaterial(material, weight - 2000);

        }

      }

    }

  }

};

void Train::deleteFromWagon(char material, int weight) {

  int matavailable = 0;
  int available = 0;
  int numWagon = 0;
  int index = 0;
  wagonNode * searchWagon = head;
  while (searchWagon != NULL) {

    materialNode * searchMat = searchWagon -> material;

    int matindex = 0;
    while (searchMat != NULL) {

      if (searchMat -> id == material) {
        matavailable = numWagon;
        index = matindex;
        available = 1;

      }
      searchMat = searchMat -> next;
      matindex++;

    }
    searchWagon = searchWagon -> next;

    numWagon++;
  }
  searchWagon = head;
  if (available == 1) {

    for (int i = 0; i < matavailable; i++) {

      if (searchWagon -> next != NULL) {
        searchWagon = searchWagon -> next;
      }

    }
    materialNode * searchMat = searchWagon -> material;
    materialNode * searchMatH = searchWagon -> material;
    for (int i = 0; i < index; i++) {
      searchMatH = searchMat;
      if (searchMat != NULL) {

        searchMat = searchMat -> next;
      }

    }

    if (weight < searchMat -> weight) {

      searchMat -> weight = searchMat -> weight - weight;
    } else {

      weight = weight - searchMat -> weight;

      searchMat -> weight = 0;

    }

    if (searchMat -> weight == 0) {

      if (searchMat -> next != NULL) {
        searchMat -> id = searchMat -> next -> id;
        searchMat -> weight = searchMat -> next -> weight;
        searchMat -> next = searchMat -> next -> next;

      } else {

        if (searchMat == searchWagon -> material) {

          searchWagon -> material = NULL;

        } else {

          searchMatH -> next = NULL;
        }

      }

      deleteFromWagon(material, weight);

    }

  }
  if (searchWagon -> material == NULL) {
    if (searchWagon == head) {
      checkempty(0);
    } else {
      checkempty(1);

    }
  }
};

void Train::printWagon() {
  wagonNode * tempWagon = head;

  if (tempWagon == NULL) {
    cout << "Train is empty!!!" << endl;
    return;
  }

  while (tempWagon != NULL) {
    materialNode * tempMat = tempWagon -> material;
    cout << tempWagon -> wagonId << ". Wagon:" << endl;
    while (tempMat != NULL) {
      cout << tempMat -> id << ": " << tempMat -> weight << "KG, ";
      tempMat = tempMat -> next;
    }
    cout << endl;
    tempWagon = tempWagon -> next;
  }
  cout << endl;
};